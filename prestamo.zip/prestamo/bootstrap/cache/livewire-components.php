<?php return array (
  'image-upload' => 'App\\Http\\Livewire\\ImageUpload',
  'productos' => 'App\\Http\\Livewire\\Productos',
  'tipo-productos' => 'App\\Http\\Livewire\\TipoProductos',
  'tiposdeproductos' => 'App\\Http\\Livewire\\Tiposdeproductos',
  'users' => 'App\\Http\\Livewire\\Users',
);