<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php if (! empty(trim($__env->yieldContent('title')))): ?> <?php echo $__env->yieldContent('title'); ?> | <?php endif; ?> <?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    <!--Estilos-->
    <link href="<?php echo e(asset('css/estilo-login.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/inicioadmin.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/estilo-usuarios.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/estilo-agregarusuario.css')); ?>" rel="stylesheet">

    <link href="<?php echo e(asset('css/productos.css')); ?>" rel="stylesheet">


    <!-- Bootstrap y Fontawesome -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
    <!-- GRAFICAS-->
    <script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <?php echo \Livewire\Livewire::styles(); ?>

</head>

<body>
    <div id="app">
        <nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm">
            <div class="container">
                <a class="navbar-brand" href="<?php echo e(url('/home')); ?>">
                    <?php echo e(config('app.name', 'Laravel')); ?>

                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <?php if(auth()->guard()->check()): ?>
                    <ul class="navbar-nav mr-auto">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("admin.home")): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(url('/Dashboard')); ?>">Inicio</a>
                        </li>
						<li class="nav-item">
                            <a href="<?php echo e(url('/productos')); ?>" class="nav-link"><i class="fab fa-laravel text-info"></i> Productos</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(url('/usuarios')); ?>">Usuarios</a>
                        </li>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(url('/Categorias')); ?>">Categorias</a>
                            </li>
                        <?php endif; ?>
                    </ul>
                    <?php endif; ?>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                        <?php if(Route::has('login')): ?>
                        <!--
                            Boton de entrar
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                        </li>
                        -->
                        <?php endif; ?>

                        <?php if(Route::has('register')): ?>
                        <!--
                            BOTON DE REGISTRAR
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                        </li>
                        -->
                        <?php endif; ?>
                        <?php else: ?>

                        <!-- Productos -->
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(url('/users')); ?>">Usuario</a>
                        </li>


                        <li class="nav-item dropdown">
                            <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                <?php echo e(Auth::user()->name); ?>

                            </a>

                            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("admin.home")): ?>
                                <a class="dropdown-item" href="<?php echo e(url('/Dashboard')); ?>" >
                                    <?php echo e(__('Dashboard')); ?>

                                </a>
                                <?php endif; ?>
                                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                    <?php echo e(__('Logout')); ?>

                                </a>

                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </div>
                        </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>

        <main class="py-2">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
    <?php echo \Livewire\Livewire::scripts(); ?>

    <script type="text/javascript">
        window.livewire.on('closeModal', () => {
            $('#exampleModal').modal('hide');
        });
    </script>
    <script src="<?php echo e(asset('js/estilo-login.js')); ?>"></script>
    <script src="<?php echo e(asset('js/inicioadmin.js')); ?>"></script>
</body>

</html>
<?php /**PATH C:\Users\conch\Documents\GitHub\Maincompleto\prestamo\resources\views/layouts/app.blade.php ENDPATH**/ ?>