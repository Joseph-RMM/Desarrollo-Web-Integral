
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('tiposdeproductos')->html();
} elseif ($_instance->childHasBeenRendered('ee4bE8w')) {
    $componentId = $_instance->getRenderedChildComponentId('ee4bE8w');
    $componentTag = $_instance->getRenderedChildComponentTagName('ee4bE8w');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ee4bE8w');
} else {
    $response = \Livewire\Livewire::mount('tiposdeproductos');
    $html = $response->html();
    $_instance->logRenderedChild('ee4bE8w', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>     
    </div>   
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\conch\Documents\GitHub\Maincompleto\prestamo\resources\views/livewire/tiposdeproductos/index.blade.php ENDPATH**/ ?>