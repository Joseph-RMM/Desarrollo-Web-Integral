
<div class="container">
	<div class="alert colordark" role="alert">
		<div class="row">
			<div class="col-lg-5 col-md-5 col-sm-1">
				<div class="usuario-white">
					<b>Usuarios</b>
				</div>
				
			</div>
			<div class="col-lg-5 col-md-5 col-sm-1">
			<?php if(session()->has('message')): ?>
				<div wire:poll.4s class="btn btn-sm btn-success" style="margin-top:0px; margin-bottom:0px;"> <?php echo e(session('message')); ?> </div>
				<?php endif; ?>
			</div>
			<div class="col-lg-2 col-md-2 col-sm-2">
				<div class="usuario-white">
					<button class="btn btn-primary btn-sm" data-toggle="modal" data-target="#exampleModal"> <i class="fas fa-user"> </i> Agregar usuario</button>

				</div>
			</div>
		</div>
	</div>

	<div class="table-responsive">

		<?php echo $__env->make('livewire.users.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<?php echo $__env->make('livewire.users.update', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<table class="table table-hover">
			<thead>
				<tr>
					<td scope="col">#</td>
					<th scope="col">Nombre</th>
					<th scope="col">Apellidos</th>
					<th scope="col">Telefono</th>
					<th scope="col">Correo</th>
					<th scope="col">Acción</th>
				</tr>
			</thead>
			<tbody>
				<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($loop->iteration); ?></td>
					<td><?php echo e($row->name); ?></td>
					<td><?php echo e($row->lastname); ?></td>
					<td><?php echo e($row->tel); ?></td>
					<td><?php echo e($row->email); ?></td>
					<td>
						<button onclick="confirm('Confirm Delete User id <?php echo e($row->id); ?>? \nDeleted Users cannot be recovered!')||event.stopImmediatePropagation()" wire:click="destroy(<?php echo e($row->id); ?>)" class="button-rojo button5"><i class="fas fa-trash-alt"></i></button>
						<button data-toggle="modal" data-target="#updateModal" class="button-verde button5" wire:click="edit(<?php echo e($row->id); ?>)"><i class="fas fa-pencil-alt"></i></button>
					</td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
	</div>
</div><?php /**PATH C:\Users\conch\Documents\GitHub\Maincompleto\prestamo\resources\views/livewire/users/view.blade.php ENDPATH**/ ?>