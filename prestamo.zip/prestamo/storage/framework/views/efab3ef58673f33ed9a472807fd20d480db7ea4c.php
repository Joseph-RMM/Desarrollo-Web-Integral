<!-- Modal -->
<div wire:ignore.self class="modal fade bd-example-modal-lg" id="exampleModal" data-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-body">
                <div class="container">
                    <div class="alert colordark" role="alert">
                        <div class="row">
                            <div class="col-lg-9 col-md-6 col-sm-2">
                                <div class="usuario-white">
                                    Agregar Producto
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="wrapper-agregarusuario">
                    <div class="form-container">
                        <div class="form-inner">
                            <form class="signup">
                                <label>Crear un nuevo Producto</label>
                                <div class="field">
                                    <label>Nombre <b class="rojo">*</b></label>
                                    <input wire:model="nombre" type="text" id="nombre" placeholder="nombre"><?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="field">
                                    <label>Descripcion <b class="rojo">*</b></label>
                                    <input wire:model="Descripcion" type="text" id="Descripcion" placeholder="Descripcion"><?php $__errorArgs = ['Descripcion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="field">
                                    <label>Añadir imagenes <b class="rojo">*</b></label>
                                    <br>
                                    <input wire:model="foto" type="file"  id="foto" placeholder="Sube aqui tu foto" multiple accept='image/x-png,image/gif,image/jpg,image/jpeg' /><?php $__errorArgs = ['foto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="field">
                                    <label>Estado actual del producto <b class="rojo">*</b></label>
                                    <br>
                                    <select wire:model="Estado_actual_del_producto">
                                        <option value="D">Estado del producto</option>
                                        <option value="P">Prestado</option>
                                        <option value="D">Disponible</option>
                                    </select>
                                </div>
                                <div class="field">
                                    <label>Id usuario <b class="rojo">*</b></label>
                                    <br>
                                    <select wire:model="id_usuario" >
                                        <option value="">usuario</option>
                                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $users): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e(auth()->user()->id); ?>"><?php echo e(auth()->user()->id); ?> </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="field">
                                    <label>Id tipo producto <b class="rojo">*</b></label>
                                    <br>
                                    <select wire:model='id_tiposdeproductos' >
                                        <option value="">Clasificacion de producto</option>
                                        <?php $__currentLoopData = $tiposdeproductos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tiposdeproductos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($tiposdeproductos->id); ?>"><?php echo e($tiposdeproductos->clasificacion); ?> </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

            </div> <!-- modal-body -->
            <div class="modal-footer">

                <button type="button" class="cancelar" data-dismiss="modal">
                    Cancelar
                </button>

                <button type="button" wire:click.prevent="store()" class="btn btn-primary close-modal">Agregar Categoria</button>

            </div>
        </div>
    </div>
</div><?php /**PATH C:\Users\conch\Documents\GitHub\Maincompleto\prestamo\resources\views/livewire/productos/create.blade.php ENDPATH**/ ?>