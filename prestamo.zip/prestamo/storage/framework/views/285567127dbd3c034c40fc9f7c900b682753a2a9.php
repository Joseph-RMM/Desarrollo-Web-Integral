
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('users')->html();
} elseif ($_instance->childHasBeenRendered('Jxy61UZ')) {
    $componentId = $_instance->getRenderedChildComponentId('Jxy61UZ');
    $componentTag = $_instance->getRenderedChildComponentTagName('Jxy61UZ');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Jxy61UZ');
} else {
    $response = \Livewire\Livewire::mount('users');
    $html = $response->html();
    $_instance->logRenderedChild('Jxy61UZ', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>     
    </div>   
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\conch\Documents\GitHub\Maincompleto\prestamo\resources\views/livewire/users/index.blade.php ENDPATH**/ ?>