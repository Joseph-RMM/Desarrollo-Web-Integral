
<?php $__env->startSection('title', __('Welcome1')); ?>
<?php $__env->startSection('content'); ?>
 
<head>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php if (! empty(trim($__env->yieldContent('title')))): ?> <?php echo $__env->yieldContent('title'); ?> | <?php endif; ?> <?php echo e(config('app.name', 'Laravel')); ?></title>
</head>
<body>
    <div class="app">
        
            <div class="container">



                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <?php if(auth()->guard()->check()): ?>
                    <ul class="navbar-nav mr-auto">
                       

						<li class="nav-item">
                            <a href="<?php echo e(url('/productos')); ?>" class="nav-link"><i class="fab fa-laravel text-info"></i> Productos</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(url('/usuarios')); ?>">Usuarios</a>
                        </li>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(url('/Categorias')); ?>">Categorias</a>
                            </li>
                      
                    </ul>
                    <?php endif; ?>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                        <?php if(Route::has('login')): ?>
                        <!--
                            Boton de entrar
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                        </li>
                        -->
                        <?php endif; ?>

                        <?php if(Route::has('register')): ?>
                        <!--
                            BOTON DE REGISTRAR
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                        </li>
                        -->
                        <?php endif; ?>
                        <?php else: ?>




                        <li class="nav-item dropdown">
                            <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                <?php echo e(Auth::user()->name); ?>

                            </a>

                            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("admin.home")): ?>
                                <a class="dropdown-item" href="<?php echo e(url('/Dashboard')); ?>" >
                                    <?php echo e(__('Dashboard')); ?>

                                </a>
                                <?php endif; ?>
                                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                    <?php echo e(__('Logout')); ?>

                                </a>

                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </div>
                        </li>
                        <?php endif; ?>
                    </ul>
                </div>

            </div>
        
    </div>
</body>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\conch\Documents\GitHub\Maincompleto\prestamo\resources\views/welcome.blade.php ENDPATH**/ ?>