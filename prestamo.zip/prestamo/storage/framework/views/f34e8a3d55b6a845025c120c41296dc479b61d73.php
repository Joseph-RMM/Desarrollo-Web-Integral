<?php $__env->startSection('title', __('Productos')); ?>




<div class="container">
    <div class="alert colordark" role="alert">
        <div class="row">
            <div class="col-lg-5 col-md-5 col-sm-1">
                <div class="usuario-white">
                    <b>Productos</b>
                </div>

            </div>
            <div class="col-lg-5 col-md-5 col-sm-1">
                <?php if(session()->has('message')): ?>
                <div wire:poll.4s class="btn btn-sm btn-success" style="margin-top:0px; margin-bottom:0px;"> <?php echo e(session('message')); ?> </div>
                <?php endif; ?>
            </div>
            <div class="col-lg-2 col-md-2 col-sm-2">
                <div class="usuario-white">
                    <button class="btn btn-primary btn-sm" data-toggle="modal" data-target="#exampleModal"> <i class="fas fa-box-open"></i> </i> Agregar Productos</button>
                </div>
            </div>
        </div>
    </div>

    <div class="table-responsive">
        <?php echo $__env->make('livewire.productos.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <table class="table table-hover">
            <thead>
                <tr>
                    <td>#</td>
                    <th>Nombre</th>
                    <th>Descripcion</th>
                    <th>Foto</th>
                    <th>Foto2</th>
                    <th>Foto3</th>
                    <th>Estado Actual Del Producto</th>
                    <th>Id Usuario</th>
                    <td>ACTIONS</td>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($row->nombre); ?></td>
                    <td><?php echo e($row->Descripcion); ?></td>
                    <td><img class="card-img-top" src="<?php echo e($row->foto); ?>"></td>
                    <td><img class="card-img-top" src="<?php echo e($row->foto2); ?>"></td>
                    <td><img class="card-img-top" src="<?php echo e($row->foto3); ?>"></td>
                    <td><?php echo e($row->Estado_actual_del_producto); ?></td>
                    <td><?php echo e($row->id_usuario); ?></td>
                    <td>
                        <button onclick="confirm('Confirm Delete Producto id <?php echo e($row->id); ?>? \nDeleted Productos cannot be recovered!')||event.stopImmediatePropagation()" wire:click="destroy(<?php echo e($row->id); ?>)" class="button-rojo button5"><i class="fas fa-trash-alt"></i></button>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div><?php /**PATH C:\Users\conch\Documents\GitHub\Maincompleto\prestamo\resources\views/livewire/productos/view.blade.php ENDPATH**/ ?>